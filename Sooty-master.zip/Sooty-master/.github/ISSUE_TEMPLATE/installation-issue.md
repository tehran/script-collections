---
name: Installation Issue
about: Issue's relating to installation or other that are not a bug.
title: ''
labels: ''
assignees: ''

---

**What is the Issue you are experiencing?**
Give a description of what issue you are facing? eg. issue installing from requirements file, etc.


**What Operating System are you using?**
The OS of the device that Sooty is running on.

**Additional Information**
Any additional information that may benefit this case.
